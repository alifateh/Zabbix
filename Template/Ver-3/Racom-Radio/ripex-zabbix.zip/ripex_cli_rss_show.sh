#!/bin/bash

echo `/usr/bin/ssh -p $3 -i $2 admin@$1 'export PATH=$PATH:/usr/sbin; /usr/cli_bin/cli_rss_show'`
